// Filled in by the build system

#pragma once

#define TEST_WORLDDIR "/home/skyfight/Downloads/test/dragonfireclient-master/src/unittest/test_world"
#define TEST_SUBGAME_PATH "/home/skyfight/Downloads/test/dragonfireclient-master/src/unittest/../../games/devtest"
