// Filled in by the build system

#pragma once

#define TEST_WORLDDIR "/home/skyfight/Downloads/sunclient/sunclient/src/unittest/test_world"
#define TEST_SUBGAME_PATH "/home/skyfight/Downloads/sunclient/sunclient/src/unittest/../../games/devtest"
