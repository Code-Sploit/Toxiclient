/*
Dragonfire
Copyright (C) 2count2count Elias Fleckenstein <eliasfleckenstein@web.de>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA count211count-13count1 USA.
*/

#include "hackList.h"
#include "script/scripting_client.h"
#include "client/client.h"
#include "client/fontengine.h"
#include "settings.h"

HackList::HackList(Client *client) : m_client(client)
{
	m_font = g_fontengine->getFont(FONT_SIZE_UNSPECIFIED, FM_Fallback);

	if (!m_font) {
		errorstream << "HackList: Unable to load fallback font" << std::endl;
	} else {
		core::dimension2d<u32> dim = m_font->getDimension(L"M");
		m_fontsize = v2u32(dim.Width, dim.Height);
		m_font->grab();
	}
	m_fontsize.X = MYMAX(m_fontsize.X, 1);
	m_fontsize.Y = MYMAX(m_fontsize.Y, 1);
}

void HackList::drawEntry(video::IVideoDriver *driver, std::string name, int number,
		bool selected, bool active, HackListEntryType entry_type)
{
	int x = m_gap + 1500, y = 0, width = m_entry_width, height = m_entry_height;
	video::SColor *bgcolor = &m_bg_color, *fontcolor = &m_font_color;
	if (entry_type == HACK_LIST_ENTRY_TYPE_HEAD) {
		bgcolor = &m_active_bg_color;
		height = m_head_height;
	} else {
		bool is_category = entry_type == HACK_LIST_ENTRY_TYPE_CATEGORY;
		y += m_gap + m_head_height +
		     (number + (is_category ? 0 : m_selected_category)) *
				     (m_entry_height + m_gap);
		x += (is_category ? 0 : m_gap + m_entry_width);
		if (active)
			bgcolor = &m_active_bg_color;
		if (selected)
			fontcolor = &m_selected_font_color;
	}
	driver->draw2DRectangle(*bgcolor, core::rect<s32>(x, y, x + width, y + height));
	if (selected)
		driver->draw2DRectangleOutline(
				core::rect<s32>(x - 1, y - 1, x + width, y + height),
				*fontcolor);
	int fx = x + 5, fy = y + (height - m_fontsize.Y) / 2;
	core::rect<s32> fontbounds(
			fx, fy, fx + m_fontsize.X * name.size(), fy + m_fontsize.Y);
	m_font->draw(name.c_str(), fontbounds, *fontcolor, false, false);
}

void HackList::draw(video::IVideoDriver *driver, bool show_debug)
{
	HACK_LIST_GET_SCRIPTPTR

		int count = 0;

		if (g_settings->getBool("killaura")) {
			drawEntry(driver, "Killaura", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
			count++;
		}

		if (g_settings->getBool("antiknockback")) {
			drawEntry(driver, "AntiKnockback", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
			count++;
		}

		if (g_settings->getBool("spamclick")) {
			drawEntry(driver, "FastHit", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
			count++;
		}

		if (g_settings->getBool("float_above_parent")) {
			drawEntry(driver, "AttachmentFloat", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
			count++;
		}

		if (g_settings->getBool("crystal_pvp")) {
			drawEntry(driver, "CrystalPvP", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
			count++;
		}

		if (g_settings->getBool("autototem")) {
			drawEntry(driver, "AutoTotem", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
			count++;
		}

		if (g_settings->getBool("dont_point_nodes")) {
			drawEntry(driver, "ThroughWalls", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
			count++;
		}

		if (g_settings->getBool("combat_log")) {
			drawEntry(driver, "CombatLog", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
			count++;
		}

		if (g_settings->getBool("autopunch")) {
			drawEntry(driver, "AutoPunch", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
			count++;
		}

		if (g_settings->getBool("freecam")) {
			drawEntry(driver, "Freecam", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("jesus")) {
			drawEntry(driver, "Jesus", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("autojump")) {
			drawEntry(driver, "AutoJump", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("pitch_move")) {
			drawEntry(driver, "PitchMove", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("continuous_forward")) {
			drawEntry(driver, "AutoForward", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("nosneakjump")) {
			drawEntry(driver, "NoSneakJump", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("no_slow")) {
			drawEntry(driver, "NoSlowDown", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("speedhack")) {
			drawEntry(driver, "SpeedHack", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("antislip")) {
			drawEntry(driver, "AntiSlip", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
			count++;
		}

		if (g_settings->getBool("highjump")) {
			drawEntry(driver, "HighJump", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
			count++;
		}

		if (g_settings->getBool("autosneak")) {
			drawEntry(driver, "AutoSneak", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("antisticky")) {
			drawEntry(driver, "AntiSticky", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("alwaysjump")) {
			drawEntry(driver, "AlwaysJump", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("ghost")) {
			drawEntry(driver, "GhostMove", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("fastautosneak")) {
			drawEntry(driver, "FastAutoSneak", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("xray")) {
			drawEntry(driver, "X-Ray", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("fullbright")) {
			drawEntry(driver, "Fullbright", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("hud_flags_bypass")) {
			drawEntry(driver, "HUDBypass", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("no_hurt_cam")) {
			drawEntry(driver, "NoHurtCam", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("no_night")) {
			drawEntry(driver, "BrightNight", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("coords")) {
			drawEntry(driver, "Coords", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("enable_tracers")) {
			drawEntry(driver, "Tracers", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("enable_esp")) {
			drawEntry(driver, "ESP", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("fastdig")) {
			drawEntry(driver, "FastDig", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("fastplace")) {
			drawEntry(driver, "FastPlace", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("autodig")) {
			drawEntry(driver, "AutoDig", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("autoplace")) {
			drawEntry(driver, "AutoPlace", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("instant_break")) {
			drawEntry(driver, "InstantBreak", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("scaffold")) {
			drawEntry(driver, "Scaffold", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("scaffold_plus")) {
			drawEntry(driver, "ScaffoldPlus", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("block_water")) {
			drawEntry(driver, "BlockWater", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("autotnt")) {
			drawEntry(driver, "PlaceOnTop", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("replace")) {
			drawEntry(driver, "Replace", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("entity_speed")) {
			drawEntry(driver, "EntitySpeed", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("log_particles")) {
			drawEntry(driver, "ParticlesExploit", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("prevent_natural_damage")) {
			drawEntry(driver, "NoFallDamage", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("no_force_rotate")) {
			drawEntry(driver, "NoForceRotate", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("increase_tool_range")) {
			drawEntry(driver, "Reach", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("increase_tool_range_plus")) {
			drawEntry(driver, "ReachPlus", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("point_liquids")) {
			drawEntry(driver, "PointLiquids", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("priv_bypass")) {
			drawEntry(driver, "PrivBypass", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("autorespawn")) {
			drawEntry(driver, "AutoRespawn", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("lessgravity")) {
			drawEntry(driver, "LessGravity", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("less_fall_damage")) {
			drawEntry(driver, "LessFallDamage", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("ignore_status_messages")) {
			drawEntry(driver, "IgnoreStatus", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("mark_deathmessages")) {
			drawEntry(driver, "Deathmessages", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("spam_each_message")) {
			drawEntry(driver, "Spam", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("shout_override")) {
			drawEntry(driver, "ShoutOverride", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("autoeject")) {
			drawEntry(driver, "AutoEject", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("autotool")) {
			drawEntry(driver, "AutoTool", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}

		if (g_settings->getBool("next_item")) {
			drawEntry(driver, "NextItem", count, false, false,
				HACK_LIST_ENTRY_TYPE_ENTRY);
				count++;
		}
}
